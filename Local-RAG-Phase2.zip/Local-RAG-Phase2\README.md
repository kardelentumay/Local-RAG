# Local RAG Assistant - Phase 2

Belge koleksiyonundan kaynak göstererek cevap üreten, tamamen yerel çalışan bir RAG uygulaması. Belgeler parçalara ayrılır, Microsoft Foundry Local ile vektörleştirilir, SQLite'ta saklanır ve en ilgili parçalar yerel sohbet modeline bağlam olarak verilir.

## Gereksinimler

- Python 3.11+
- Windows 10/11 (WinML paketi önerilir), macOS veya Linux
- İlk model indirmesi için internet; sonraki çalıştırmalar çevrimdışı olabilir

## Kurulum

```powershell
python -m venv .venv
.venv\Scripts\Activate.ps1
python -m pip install -e .
```

Windows dışındaki sistemlerde etkinleştirme komutu `source .venv/bin/activate` biçimindedir.

## Kullanım

Belgeleri `documents/` klasörüne koyun. Desteklenen türler: `.txt`, `.md`, `.pdf`.

```powershell
local-rag ingest documents
local-rag status
local-rag search "Kayıt şartları nelerdir?"
local-rag ask "Kayıt şartları nelerdir?"
local-rag chat
```

İlk `ingest` çağrısı embedding modelini, ilk `ask` çağrısı sohbet modelini indirip yükleyebilir. Varsayılanlar:

- Embedding: `qwen3-0.6b-embedding`
- Chat: `qwen2.5-0.5b`
- Veritabanı: `data/knowledge.db`

Farklı ayarlar komut seçenekleriyle verilebilir:

```powershell
local-rag --db data/notes.db --embedding-model qwen3-0.6b-embedding ingest documents --chunk-size 1200 --overlap 200
local-rag --chat-model qwen2.5-0.5b ask "Soru" --top-k 3
```

`ingest`, aynı dosya değişmemişse onu yeniden işlemez; değişmiş dosyanın eski parçalarını atomik olarak yeniler. Cevap bağlamda yoksa sistem tahmin yürütmemesi için yönlendirilir. Çıktıda kullanılan kaynak ve benzerlik puanları ayrıca gösterilir.

## Mimari

1. `documents.py`: TXT/Markdown/PDF okuma ve örtüşmeli parçalara ayırma.
2. `foundry.py`: Foundry Local model yaşam döngüsü, embedding ve chat çağrıları.
3. `store.py`: SQLite şeması, belge sürümleme ve brute-force cosine retrieval.
4. `service.py`: ingestion ve retrieve-augment-generate orkestrasyonu.
5. `cli.py`: `ingest`, `search`, `ask`, `chat`, `status` arayüzü.

Koleksiyon küçük tutulduğu için vektörler SQLite'tan belleğe alınıp cosine similarity Python'da hesaplanır. Büyük koleksiyonlarda özel bir vektör indeksi gerekir.

## Test

```powershell
$env:PYTHONPATH="src"
python -m unittest discover -s tests -v
```

Testler Foundry modeli indirmez; deterministik sahte embedding/chat adaptörleri kullanır.
