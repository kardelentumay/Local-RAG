import hashlib
import math
import tempfile
import unittest
from pathlib import Path

from local_rag.service import RAGService
from local_rag.store import SQLiteStore


class KeywordEmbeddings:
    words = ("saat", "bilgisayar", "rag", "kaynak")

    def embed(self, texts):
        vectors = []
        for text in texts:
            lowered = text.lower()
            vector = [float(lowered.count(word)) for word in self.words]
            if not any(vector):
                vector.append(1.0)
            else:
                vector.append(0.0)
            vectors.append(vector)
        return vectors


class RecordingChat:
    def __init__(self):
        self.messages = None

    def complete(self, messages):
        self.messages = messages
        return "Dersler 09.00'da başlar [1]."


class ServiceTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        root = Path(self.temp.name)
        self.docs = root / "docs"
        self.docs.mkdir()
        (self.docs / "program.md").write_text(
            "Dersler hafta içi saat 09.00'da başlar.\n\nKatılımcılar bilgisayar getirmelidir.\n\nRAG cevapları kaynaklara dayanır.",
            encoding="utf-8",
        )
        self.store = SQLiteStore(root / "knowledge.db")
        self.chat = RecordingChat()
        self.service = RAGService(self.store, KeywordEmbeddings(), self.chat)

    def tearDown(self):
        self.temp.cleanup()

    def test_ingest_is_idempotent_and_searches(self):
        first = self.service.ingest(self.docs, chunk_size=100, overlap=10)
        second = self.service.ingest(self.docs, chunk_size=100, overlap=10)
        self.assertEqual(1, first.processed)
        self.assertGreater(first.chunks, 0)
        self.assertEqual(1, second.skipped)
        self.assertEqual("program.md", self.service.search("saat kaçta?", 1)[0].source)

    def test_answer_includes_retrieved_context(self):
        self.service.ingest(self.docs, chunk_size=100, overlap=10)
        answer = self.service.answer("Dersler saat kaçta?", 1)
        self.assertIn("[1]", answer.text)
        self.assertIn("BAĞLAM", self.chat.messages[1]["content"])
        self.assertEqual(1, len(answer.sources))


if __name__ == "__main__":
    unittest.main()
