from __future__ import annotations

import hashlib
from dataclasses import dataclass
from pathlib import Path

from .documents import chunk_text, discover_documents, read_document
from .foundry import ChatProvider, EmbeddingProvider
from .models import Answer, SearchResult
from .store import SQLiteStore


SYSTEM_PROMPT = """Sen yalnızca verilen yerel kaynaklara dayanarak cevap veren bir asistansın.
Kurallar:
- Bağlamda bulunmayan bilgiyi tahmin etme.
- Yeterli bilgi yoksa açıkça 'Bu bilgi yüklenen belgelerde bulunmuyor.' de.
- Cevabı kısa ve anlaşılır tut.
- İddiaların yanında [1], [2] biçiminde kaynak numarası kullan.
"""


@dataclass(frozen=True)
class IngestReport:
    processed: int
    skipped: int
    chunks: int


class RAGService:
    def __init__(self, store: SQLiteStore, embeddings: EmbeddingProvider, chat: ChatProvider | None = None):
        self.store = store
        self.embeddings = embeddings
        self.chat = chat

    def ingest(self, path: Path, chunk_size: int = 1200, overlap: int = 200, batch_size: int = 16) -> IngestReport:
        if batch_size < 1:
            raise ValueError("batch_size en az 1 olmalıdır")
        processed = skipped = total_chunks = 0
        base = path if path.is_dir() else path.parent
        for document in discover_documents(path):
            source = document.relative_to(base).as_posix()
            raw = document.read_bytes()
            digest = hashlib.sha256(raw).hexdigest()
            if self.store.has_document(source, digest):
                skipped += 1
                continue
            chunks = chunk_text(read_document(document), source, chunk_size, overlap)
            vectors: list[list[float]] = []
            for start in range(0, len(chunks), batch_size):
                vectors.extend(self.embeddings.embed([item.content for item in chunks[start : start + batch_size]]))
            self.store.replace_document(source, digest, chunks, vectors)
            processed += 1
            total_chunks += len(chunks)
        return IngestReport(processed, skipped, total_chunks)

    def search(self, question: str, top_k: int = 3) -> list[SearchResult]:
        clean = question.strip()
        if not clean:
            raise ValueError("Soru boş olamaz")
        return self.store.search(self.embeddings.embed([clean])[0], top_k)

    def answer(self, question: str, top_k: int = 3) -> Answer:
        if self.chat is None:
            raise RuntimeError("Cevap üretmek için chat sağlayıcısı gerekli")
        results = self.search(question, top_k)
        if not results:
            return Answer("Bu bilgi yüklenen belgelerde bulunmuyor.", [])
        context = "\n\n".join(
            f"[{index}] Kaynak: {item.source}, parça: {item.position + 1}\n{item.content}"
            for index, item in enumerate(results, start=1)
        )
        prompt = f"BAĞLAM:\n{context}\n\nSORU:\n{question.strip()}"
        text = self.chat.complete([{"role": "system", "content": SYSTEM_PROMPT}, {"role": "user", "content": prompt}])
        return Answer(text.strip(), results)
