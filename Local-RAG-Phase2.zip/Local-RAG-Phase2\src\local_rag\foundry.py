from __future__ import annotations

from collections.abc import Sequence
from typing import Protocol


class EmbeddingProvider(Protocol):
    def embed(self, texts: Sequence[str]) -> list[list[float]]: ...


class ChatProvider(Protocol):
    def complete(self, messages: list[dict[str, str]]) -> str: ...


class FoundryRuntime:
    def __init__(self, app_name: str = "local-rag-assistant"):
        try:
            from foundry_local_sdk import Configuration, FoundryLocalManager
        except ImportError as exc:
            raise RuntimeError(
                "Foundry Local SDK bulunamadı. Windows'ta 'pip install foundry-local-sdk-winml' komutunu çalıştırın."
            ) from exc
        try:
            FoundryLocalManager.initialize(Configuration(app_name=app_name))
        except Exception as exc:
            if "already" not in str(exc).lower() and "initializ" not in str(exc).lower():
                raise
        self.manager = FoundryLocalManager.instance
        self._models: dict[str, object] = {}

    def load_model(self, alias: str):
        if alias not in self._models:
            model = self.manager.catalog.get_model(alias)
            model.download()
            model.load()
            self._models[alias] = model
        return self._models[alias]

    def close(self) -> None:
        for model in reversed(list(self._models.values())):
            model.unload()
        self._models.clear()


class FoundryEmbeddings:
    def __init__(self, runtime: FoundryRuntime, model_alias: str):
        self.client = runtime.load_model(model_alias).get_embedding_client()

    def embed(self, texts: Sequence[str]) -> list[list[float]]:
        values = list(texts)
        if not values:
            return []
        response = self.client.generate_embeddings(values)
        return [list(item.embedding) for item in response.data]


class FoundryChat:
    def __init__(self, runtime: FoundryRuntime, model_alias: str):
        self.client = runtime.load_model(model_alias).get_chat_client()

    def complete(self, messages: list[dict[str, str]]) -> str:
        response = self.client.complete_chat(messages)
        return response.choices[0].message.content or ""
